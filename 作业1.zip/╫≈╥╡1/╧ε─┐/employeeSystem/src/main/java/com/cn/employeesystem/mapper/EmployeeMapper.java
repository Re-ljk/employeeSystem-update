package com.cn.employeesystem.mapper;

import com.cn.employeesystem.entity.Employee;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper

public interface EmployeeMapper {
    //��ѯ����Ա����Ϣ
    public List<Employee> findAllEmployee();

}
